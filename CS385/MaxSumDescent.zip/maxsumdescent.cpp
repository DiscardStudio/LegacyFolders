/*******************************************************************************
 * Name        : maxsumdescent.cpp
 * Author      : Michael Sanchez and Simrun Heir
 * Version     : 1.0
 * Date        : 4/28/2021
 * Description : Dynamic programming solution to max sum descent problem.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

const char DELIMITER = ' ';

int **values, // This is your 2D array of values, read from the file.
    **sums;   // This is your 2D array of partial sums, used in DP.

int num_rows; // num_rows tells you how many rows the 2D array has.
              // The first row has 1 column, the second row has 2 columns, and
              // so on...

/**
 * Displays the 2D array of values read from the file in the format of a table.
 */
void display_table() {
    for(int r=0;r<num_rows;r++) {
        for(int c=0;c<r+1;c++) {
			    cout << values[r][c] << (c==r?"":" ");
        }
      cout << endl;
    }
}

/**
 * Returns the maximum sum possible in the triangle of values.
 * By starting at the top of the triangle and moving to adjacent numbers on the
 * row below, this function uses dynamic programming to build up another table
 * of partial sums.
 */
int compute_max_sum() {
    // TODO
    if(num_rows==0)
      return 0;
    // Populate the 2D array of partial sums. It should still work even if
    // num_rows is 0 (i.e. the file was blank).
  	for(int c=0;c<num_rows;c++)
      sums[num_rows-1][c]=values[num_rows-1][c];
	  for(int r=num_rows-2;r>0;r--) {
        for(int c=0;c<r;c++) {
            sums[r][c]=values[r][c]+max(sums[r+1][c],sums[r+1][c+1]);
        }
    }
  	sums[0][0]=(num_rows==1?values[0][0]:values[0][0]+max(sums[1][0],sums[1][1]));
    // Loop over the last row to find the max sum.

    // Return the max sum.
    return sums[0][0];
}

/**
 * Returns a vector of ints with the values from the top to the bottom of the
 * triangle that comprise the maximum sum.
 */
vector<int> backtrack_solution() {
    vector<int> solution;
    // TODO
    if(num_rows>0)
      solution.push_back(values[0][0]);
  	int c=0;
	  for(int r=0;r<num_rows-1;r++) {
    	if (sums[r+1][c] > sums[r+1][c+1]) {
          	solution.push_back(sums[r+1][c]);
        } else {
        	solution.push_back(sums[r+1][c+1]);
          	c++;
        }
    }
    return solution;
}

/**
  * Takes an string and returns an array
  * row_to_array("74 32 11") --> [74, 32, 11]
  */
vector<int> row_to_array(string s) {
  vector<int> temp;
  int tag=0;
  for(size_t i=0; i<s.size(); i++) {
  	if (s[i] == DELIMITER) {
    	temp.push_back(stoi(s.substr(tag,i)));
      	tag = i+1;
    }
    else if(s.size()==i+1) {
    	temp.push_back(stoi(s.substr(tag)));
    }
  }
  return temp;
}

/**
 * Reads the contents of the file into the global 2D array 'values'. If
 * successful, the function also allocates memory for the 2D array 'sums'.
 */
bool load_values_from_file(const string &filename) {
    ifstream input_file(filename.c_str());
    if (!input_file) {
        cerr << "Error: Cannot open file '" << filename << "'." << endl;
        return false;
    }
    input_file.exceptions(ifstream::badbit);
    string line;
    vector<string> data;
    try {
        while (getline(input_file, line)) {
            data.push_back(line);
        }
        input_file.close();
    } catch (const ifstream::failure &f) {
        cerr << "Error: An I/O error occurred reading '" << filename << "'.";
        return false;
    }
    // TODO
  	num_rows = data.size();
  	values = new int *[num_rows]; 
  	sums = new int *[num_rows];
  	for (int i=0; i<num_rows; i++) {
        vector<int> temp = row_to_array(data[i]);
      	values[i] = new int[i+1];
      	for (size_t j=0; j<temp.size(); j++) {
        	values[i][j] = temp[j];
        }
        sums[i] = new int[i+1];
    }	
  	/*
  	num_rows = data.size();
  	values = new int *[num_rows]; 
  	sums = new int *[num_rows];
  	for (int i=0; i<num_rows; i++) {
        vector<int> temp = row_to_array(data[i]);
        cout << (&temp[0])[0] << endl;
      	values[i] = &temp[0];
        sums[i] = new int [num_rows];
    }
    */
    return true;
}

/**
 * Frees up the memory allocated for the 2D array of values and the 2D array of
 * partial sums.
 */
void cleanup() {
    // TODO
  	/*for(int r=0;r<num_rows;r++)
      for(int c=0;c<r+1;r++) {
        delete values[r][c];
        delete sums[r][c];
      } */
  
  	delete[]values;
  	delete[]sums;
}

int main(int argc, char * const argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }
    string filename(argv[1]);
    if (!load_values_from_file(filename)) {
        return 1;
    }

    // TODO
	  display_table();
  	cout << "Max sum: " << compute_max_sum() << endl;
  	cout << "Values: [";
  	vector<int> solutions = backtrack_solution();
  	for(size_t x=0;x<solutions.size();x++)
      	cout << solutions[x] << (x==solutions.size()-1?"]":", ");
  	cleanup();
    return 0;
}

/*

*/